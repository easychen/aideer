var content=(function(){"use strict";function k(s){return s}class b{constructor(t=300){this.minSize=t}scanImages(){const t=[];return document.querySelectorAll("img").forEach(e=>{const n=e.getBoundingClientRect(),r=n.width||e.naturalWidth||e.width,o=n.height||e.naturalHeight||e.height;(r>=this.minSize||o>=this.minSize)&&t.push({type:"image",src:e.src,alt:e.alt,title:e.title,width:Math.round(r),height:Math.round(o),element:e})}),t}scanVideos(){const t=[];return document.querySelectorAll("video").forEach(e=>{const n=e.getBoundingClientRect(),r=n.width||e.videoWidth||e.width,o=n.height||e.videoHeight||e.height;(r>=this.minSize||o>=this.minSize)&&t.push({type:"video",src:e.src||e.currentSrc,title:e.title,width:Math.round(r),height:Math.round(o),element:e})}),t}scanBackgroundImages(){const t=[];return document.querySelectorAll("*").forEach(e=>{const r=window.getComputedStyle(e).backgroundImage;if(r&&r!=="none"){const o=r.match(/url\(['"]?([^'"]+)['"]?\)/);if(o&&o[1]){const d=e.getBoundingClientRect(),c=d.width,a=d.height;(c>=this.minSize||a>=this.minSize)&&t.push({type:"image",src:o[1],title:e.getAttribute("title")||void 0,alt:e.getAttribute("alt")||void 0,width:Math.round(c),height:Math.round(a),element:e})}}}),t}getAllMedia(){const t=this.scanImages(),i=this.scanVideos(),e=this.scanBackgroundImages();return[...t,...i,...e].filter((o,d,c)=>d===c.findIndex(a=>a.src===o.src)).sort((o,d)=>d.width*d.height-o.width*o.height)}setMinSize(t){this.minSize=t}}class E{constructor(){this.selectedItems=new Set,this.minWidth=100,this.allMediaItems=[],this.mediaScanner=new b(100),this.overlay=this.createOverlay(),this.attachEventListeners()}async saveSingleMedia(t,i){try{const e=await this.getMediaItemInfo(t),n=await this.getApiUrl();if((await fetch(`${n}/api/files/import-media`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mediaItems:[e],source:i||window.location.href})})).ok)this.showNotification("保存成功","文件已保存到 AiDeer","success");else throw new Error("保存失败")}catch(e){console.error("Save single media failed:",e),this.showNotification("保存失败","请检查网络连接和后端服务","error")}}async getMediaItemInfo(t){return new Promise(i=>{const e=new Image,n=document.createElement("video");/\.(mp4|webm|ogg|avi|mov)(\?.*)?$/i.test(t)?(n.onloadedmetadata=()=>{i({src:t,type:"video",width:n.videoWidth||0,height:n.videoHeight||0,element:n})},n.onerror=()=>{i({src:t,type:"video",width:0,height:0,element:n})},n.src=t):(e.onload=()=>{i({src:t,type:"image",width:e.naturalWidth||0,height:e.naturalHeight||0,element:e})},e.onerror=()=>{i({src:t,type:"image",width:0,height:0,element:e})},e.src=t)})}showNotification(t,i,e){const n=document.createElement("div");n.style.cssText=`
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${e==="success"?"#4CAF50":"#f44336"};
      color: white;
      padding: 15px 20px;
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
      z-index: 10001;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      max-width: 300px;
    `,n.innerHTML=`
      <div style="font-weight: bold; margin-bottom: 5px;">${t}</div>
      <div>${i}</div>
    `,document.body.appendChild(n),setTimeout(()=>{n.parentNode&&n.parentNode.removeChild(n)},3e3)}createOverlay(){const t=document.createElement("div");t.id="media-collector-overlay",t.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.8);
      z-index: 10000;
      display: none;
      overflow-y: auto;
      padding: 20px;
      box-sizing: border-box;
    `;const i=document.createElement("div");i.style.cssText=`
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 8px;
      padding: 20px;
    `;const e=document.createElement("div");e.style.cssText=`
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      border-bottom: 1px solid #eee;
      padding-bottom: 15px;
    `;const n=document.createElement("h2");n.textContent="AiDeer Importer",n.style.cssText=`
      margin: 0;
      color: #333;
      font-size: 24px;
    `;const r=document.createElement("div");r.style.cssText=`
      display: flex;
      align-items: center;
      gap: 10px;
      margin: 10px 0;
    `;const o=document.createElement("label");o.textContent="最小宽度:",o.style.cssText=`
      font-size: 14px;
      color: #666;
    `;const d=document.createElement("input");d.type="range",d.min="50",d.max="1000",d.value="100",d.style.cssText=`
      width: 150px;
    `;const c=document.createElement("span");c.textContent="100px",c.style.cssText=`
      font-size: 14px;
      color: #333;
      min-width: 50px;
    `,d.addEventListener("input",M=>{const x=M.target.value;c.textContent=`${x}px`,this.minWidth=parseInt(x),this.filterAndRenderMedia()}),r.appendChild(o),r.appendChild(d),r.appendChild(c);const a=document.createElement("div");a.style.cssText=`
      display: flex;
      gap: 10px;
      align-items: center;
    `;const m=document.createElement("button");m.textContent="全选",m.style.cssText=`
      padding: 8px 16px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    `,m.onclick=()=>this.selectAll();const u=document.createElement("button");u.textContent="导入选中",u.style.cssText=`
      padding: 8px 16px;
      background: #28a745;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    `,u.onclick=()=>this.importSelected();const g=document.createElement("button");g.textContent="关闭",g.style.cssText=`
      padding: 8px 16px;
      background: #dc3545;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    `,g.onclick=()=>this.hide(),a.appendChild(m),a.appendChild(u),a.appendChild(g),e.appendChild(n),e.appendChild(r),e.appendChild(a);const v=document.createElement("div");return v.id="media-grid",v.style.cssText=`
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 15px;
      max-height: 70vh;
      overflow-y: auto;
    `,i.appendChild(e),i.appendChild(v),t.appendChild(i),t}attachEventListeners(){document.addEventListener("keydown",t=>{t.key==="Escape"&&this.hide()}),this.overlay.addEventListener("click",t=>{t.target===this.overlay&&this.hide()})}show(){document.body.contains(this.overlay)||document.body.appendChild(this.overlay),this.overlay.style.display="block",this.loadMedia()}hide(){this.overlay.style.display="none"}async loadMedia(){const t=this.overlay.querySelector("#media-grid");t.innerHTML='<div style="text-align: center; padding: 20px;">正在扫描媒体文件...</div>';try{this.allMediaItems=await this.mediaScanner.getAllMedia(),this.filterAndRenderMedia()}catch(i){console.error("Failed to load media:",i),t.innerHTML='<div style="text-align: center; padding: 20px; color: red;">加载媒体文件失败</div>'}}filterAndRenderMedia(){const t=this.allMediaItems.filter(i=>i.width>=this.minWidth);this.renderMediaItems(t)}renderMediaItems(t){const i=this.overlay.querySelector("#media-grid");if(t.length===0){i.innerHTML='<div style="text-align: center; padding: 20px;">未找到媒体文件</div>';return}i.innerHTML="",t.forEach(e=>{const n=document.createElement("div");n.className="media-item",n.style.cssText=`
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 10px;
        background: white;
        cursor: pointer;
        transition: all 0.2s;
        position: relative;
      `;const r=document.createElement("input");r.type="checkbox",r.style.cssText=`
        position: absolute;
        top: 10px;
        right: 10px;
        width: 18px;
        height: 18px;
        cursor: pointer;
      `,r.checked=this.selectedItems.has(e.src),r.addEventListener("change",()=>{r.checked?(this.selectedItems.add(e.src),n.style.borderColor="#007bff",n.style.backgroundColor="#f8f9fa"):(this.selectedItems.delete(e.src),n.style.borderColor="#ddd",n.style.backgroundColor="white")});const o=document.createElement("div");if(o.style.cssText=`
        width: 100%;
        height: 120px;
        background: #f5f5f5;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 8px;
        overflow: hidden;
      `,e.type==="image"){const a=document.createElement("img");a.src=e.src,a.style.cssText=`
          max-width: 100%;
          max-height: 100%;
          object-fit: cover;
        `,a.onerror=()=>{o.innerHTML='<span style="color: #666;">图片加载失败</span>'},o.appendChild(a)}else if(e.type==="video"){const a=document.createElement("video");a.src=e.src,a.style.cssText=`
          max-width: 100%;
          max-height: 100%;
          object-fit: cover;
        `,a.controls=!1,a.muted=!0,a.onerror=()=>{o.innerHTML='<span style="color: #666;">视频加载失败</span>'},o.appendChild(a)}const d=document.createElement("div");d.style.cssText=`
        font-size: 12px;
        color: #666;
        line-height: 1.4;
      `;const c=e.src.split("/").pop()||e.src;d.innerHTML=`
        <div style="font-weight: bold; margin-bottom: 4px;">${e.type==="image"?"图片":"视频"}</div>
        <div style="word-break: break-all;">${c}</div>
        ${e.width&&e.height?`<div>${e.width} × ${e.height}</div>`:""}
      `,n.appendChild(r),n.appendChild(o),n.appendChild(d),n.addEventListener("click",a=>{a.target!==r&&r.click()}),i.appendChild(n)})}selectAll(){const t=this.overlay.querySelectorAll('input[type="checkbox"]'),i=Array.from(t).every(e=>e.checked);t.forEach(e=>{i?(e.checked=!1,e.dispatchEvent(new Event("change"))):(e.checked=!0,e.dispatchEvent(new Event("change")))})}async getApiUrl(){return(await chrome.storage.sync.get(["apiUrl"])).apiUrl||"http://localhost:3001"}async importSelected(){if(this.selectedItems.size===0){alert("请先选择要导入的媒体文件");return}try{const i=(await this.mediaScanner.getAllMedia()).filter(r=>this.selectedItems.has(r.src)),e=await this.getApiUrl(),n=await fetch(`${e}/api/files/import-media`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mediaItems:i,source:window.location.href})});if(n.ok){const r=await n.json();alert(`成功导入 ${r.imported} 个媒体文件`),this.selectedItems.clear(),this.hide()}else throw new Error("导入失败")}catch(t){console.error("Import failed:",t),alert("导入失败，请检查网络连接和后端服务")}}}const S={matches:["<all_urls>"],main(){console.log("AiDeer Importer content script loaded");const s=new E;chrome.runtime.onMessage.addListener((t,i,e)=>{t.action==="show-media-collector"?(s.show(),e({success:!0})):t.action==="save-single-media"&&(s.saveSingleMedia(t.mediaUrl,t.pageUrl),e({success:!0}))}),document.addEventListener("keydown",t=>{t.ctrlKey&&t.shiftKey&&t.key==="M"&&(t.preventDefault(),s.show())})}},y=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function l(s,...t){}const I={debug:(...s)=>l(console.debug,...s),log:(...s)=>l(console.log,...s),warn:(...s)=>l(console.warn,...s),error:(...s)=>l(console.error,...s)};class f extends Event{constructor(t,i){super(f.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=i}static EVENT_NAME=w("wxt:locationchange")}function w(s){return`${y?.runtime?.id}:content:${s}`}function T(s){let t,i;return{run(){t==null&&(i=new URL(location.href),t=s.setInterval(()=>{let e=new URL(location.href);e.href!==i.href&&(window.dispatchEvent(new f(e,i)),i=e)},1e3))}}}class h{constructor(t,i){this.contentScriptName=t,this.options=i,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=w("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=T(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return y.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,i){const e=setInterval(()=>{this.isValid&&t()},i);return this.onInvalidated(()=>clearInterval(e)),e}setTimeout(t,i){const e=setTimeout(()=>{this.isValid&&t()},i);return this.onInvalidated(()=>clearTimeout(e)),e}requestAnimationFrame(t){const i=requestAnimationFrame((...e)=>{this.isValid&&t(...e)});return this.onInvalidated(()=>cancelAnimationFrame(i)),i}requestIdleCallback(t,i){const e=requestIdleCallback((...n)=>{this.signal.aborted||t(...n)},i);return this.onInvalidated(()=>cancelIdleCallback(e)),e}addEventListener(t,i,e,n){i==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),t.addEventListener?.(i.startsWith("wxt:")?w(i):i,e,{...n,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),I.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:h.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){const i=t.data?.type===h.SCRIPT_STARTED_MESSAGE_TYPE,e=t.data?.contentScriptName===this.contentScriptName,n=!this.receivedMessageIds.has(t.data?.messageId);return i&&e&&n}listenForNewerScripts(t){let i=!0;const e=n=>{if(this.verifyScriptStartedEvent(n)){this.receivedMessageIds.add(n.data.messageId);const r=i;if(i=!1,r&&t?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",e),this.onInvalidated(()=>removeEventListener("message",e))}}function L(){}function p(s,...t){}const C={debug:(...s)=>p(console.debug,...s),log:(...s)=>p(console.log,...s),warn:(...s)=>p(console.warn,...s),error:(...s)=>p(console.error,...s)};return(async()=>{try{const{main:s,...t}=S,i=new h("content",t);return await s(i)}catch(s){throw C.error('The content script "content" crashed on startup!',s),s}})()})();
content;